package sample;

import sample.model.Aluno;
import sample.model.Endereco;
import sample.model.Pessoal;
import sample.model.Professor;

public class Main {


    public static void main(String[] args) {
        Pessoal pessoa = new Pessoal();
        pessoa.setNome("Lucas");
        pessoa.setEmail("lucasecker@gmail.com");
        pessoa.setTelefone("984595603");


        Endereco endereco = new Endereco();
        endereco.setRua("Joao de barro");
        endereco.setNumero(93);
        endereco.setBairro("Canasvieiras");
        endereco.setCidade("Florianópolis");

        Aluno aluno = new Aluno();
        aluno.getMatricula("90271");

        int numero = 7;

        if (numero <= 7){

        }else{

            System.out.println("Aprovado");
        }

        Professor professor = new Professor();
        professor.setSalario("R$10,000");

        System.out.println(pessoa);
    }

}