package sample.model;

public class Aluno{

    private String matricula;
    private int media;

    public String getMatricula(String s) {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public int getMedia(int i) {
        return media;
    }

    public void setMedia(int media) {
        this.media = media;
    }

    @Override
    public String toString() {
        return "Matícula: " + matricula + "Média: " + media;
    }
}
