package sample.model;


public class Endereco {

    private String Rua;
    private int Numero;
    private String Bairro;
    private String Cidade;

    public void setRua(String Rua) { this.Rua = Rua; }

    public String getRua() { return this.Rua; }

    public void setNumero(int Numero) { this.Numero = Numero; }

    public int getNumero() { return this.Numero; }

    public void setBairro(String Bairro) { this.Bairro = Bairro; }

    public String getBairro() { return this.Bairro; }

    public void setCidade(String Cidade) { this.Cidade = Cidade; }

    public String getCidade() { return this.Cidade; }

    public String toString() {
        return "Rua " + Rua + ", " + Numero + ", " + Bairro + ", " + Cidade;


    }

}