package sample;

import sample.model.Produto;

public class Main {


    public static void main(String[] args) {

        Produto produto = new Produto();
        produto.setNome("Tijolo da Supreme");
        produto.setPreco("R$ 10,000");
        System.out.println(produto);

    }

}