package sample.model;

public class Aluno{

    public class Aluno extends Pessoa{
        private int nota1;
        private int nota2;
        private double media;


        public Aluno(String nome, int nota1, int nota2, double media) {
            super(nome);
            this.nota1 = nota1;
            this.nota2 = nota2;
            this.media = media;
        }

        public int getNota1() {
            return nota1;
        }

        public void setNota1(int nota1) {
            this.nota1 = nota1;
        }

        public int getNota2() {
            return nota2;
        }

        public void setNota2(int nota2) {
            this.nota2 = nota2;
        }

        public double getMedia() {
            return media;
        }

        public void setMedia(double media) {
            this.media = media;
        }

        @Override
        public String toString() {
            return super.toString() + " - Aluno " + "\nNota 1: " + nota1 + "\nNota 2: " + nota2 + "\nMédia: " + media;
        }


    }
