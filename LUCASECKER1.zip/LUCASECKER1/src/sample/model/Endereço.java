package sample.model;

public class Endereço extends Pessoa {

    private String Rua;
    private int Uf;
    private String CEP;
    private String Cidade;
    private String Pais;

    public void setRua(String Rua) { this.Rua = Rua; }

    public String getRua() { return this.Rua; }

    public void setUf(int Uf) { this.Uf = Uf; }

    public int getUf() { return this.Uf; }

    public void setCep(String Cep) { this.Cep = Cep; }

    public String getCep() { return this.Cep; }

    public void setCidade(String Cidade) { this.Cidade = Cidade; }

    public String getCidade() { return this.Cidade; }

    public void setPais(String Pais) { this.Pais = Pais; }

    public String getPais() { return this.Pais; }

    public String toString() {
        return "Uf " + Rua + ", " + Cep + ", " + Pais + ", " + Cidade;

    }

}

