package sample.model;

public abstract class  Pessoa {
    private String nome;

    public Pessoa(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "\nNome: " + nome;
    }

    public Pessoa(String telefone) {
        this.telefone = telefone;
    }

    public String getTelefone() {
        return telefone;
    }

    @Override
    public String toString() {
        return "\nTelefone: " + telefone;
    }


    public class Professor extends Pessoa {

        private String salario;

        public String getSalario() {
            return salario;
        }

        public void setSalario(String salario) {
            this.salario = salario;
        }

